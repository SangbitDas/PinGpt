# PinGPT Chat - Chrome Extension

A powerful Chrome extension that allows you to pin your favorite ChatGPT conversations for quick access and better organization.

## 🚀 Features

### Core Features
- **Pin Conversations**: Pin important ChatGPT conversations to keep them easily accessible
- **Category Management**: Organize pinned chats into custom categories
- **Quick Access**: Access pinned conversations from the extension popup or full page view
- **Cross-Session Persistence**: Pinned chats are saved and synced across browser sessions
- **Search Functionality**: Search through your pinned conversations by name

### Advanced Features
- **Category Filtering**: Filter conversations by categories in the full page view
- **Manage Categories**: Create, search, and delete custom categories
- **Clean UI**: ChatGPT-style interface design for seamless experience
- **Keyboard Shortcuts**: Enter to submit, Escape to cancel in modals

## 📦 Installation

### Method 1: Developer Mode (Recommended)
1. Download all files to a folder:
   - `manifest.json`
   - `content.js`
   - `popup.html`
   - `popup.js`
   - `fullpage.html`
   - `fullpage.js`
   - `pin.png` (optional logo)

2. Open Chrome and navigate to `chrome://extensions/`

3. Enable "Developer mode" in the top right corner

4. Click "Load unpacked" and select the folder containing the extension files

5. The extension will be installed and ready to use!

### Method 2: Package as CRX (For Distribution)
1. Zip all extension files into a `.zip` file
2. Change the extension from `.zip` to `.crx`
3. Distribute the `.crx` file for easy installation

## 🎯 How to Use

### Basic Usage

1. **Navigate to ChatGPT**: Go to [chat.openai.com](https://chat.openai.com) or [chatgpt.com](https://chatgpt.com)

2. **Pin a Conversation**:
   - Look for the pin icon (📌) in the 3-dot menu of any chat
   - Click the pin icon to pin the conversation
   - The chat will now appear in your pinned chats

3. **Access Pinned Chats**:
   - Click the extension icon in Chrome toolbar
   - View your pinned conversations in the popup
   - Click "Full Page View" for advanced features

### Advanced Features

#### Category Management
1. **Create Categories**:
   - Click the "Manage" button in the full page view
   - Enter a category name in the "Create New Category" section
   - Click "Create" to add the category

2. **Organize Chats**:
   - Click the "+ Add" button on any chat card
   - Select a category from the popup modal
   - Or create a new category on the fly

3. **Filter by Category**:
   - Use category buttons to filter conversations
   - "All Chats" shows all pinned conversations
   - Click any category button to filter by that category

#### Search Functionality
- Use the search bar to find specific conversations
- Search works within the current category filter
- Case-insensitive search through conversation names

## 🔧 Technical Details

### File Structure
```
pin_gpt/
├── manifest.json    # Extension configuration
├── content.js       # Main extension logic (injects into ChatGPT)
├── popup.html       # Extension popup interface
├── popup.js         # Popup functionality
├── fullpage.html    # Full page view interface
├── fullpage.js      # Full page view logic
├── pin.png         # Logo image (optional)
└── README.md       # This file
```

### Permissions Used
- `storage`: Save pinned chats and categories locally
- `activeTab`: Access the current ChatGPT tab
- Host permissions for ChatGPT domains

### Data Storage
- **Pinned Chats**: Stored in Chrome's sync storage
- **Categories**: Custom categories for organization
- **Chat-Category Relations**: Links between chats and categories

## 🎨 User Interface

### ChatGPT-Style Design
- Clean, modern interface matching ChatGPT's design language
- Subtle animations and hover effects
- Consistent color scheme and typography
- Responsive design for all screen sizes

### Interface Components
1. **Extension Popup**: Quick access to recent pinned chats
2. **Full Page View**: Complete management interface
3. **Category Management**: Modal for organizing categories
4. **Search Interface**: Find conversations quickly

## 🛠️ Development

### Adding New Features
1. **Content Script** (`content.js`): Modify ChatGPT page behavior
2. **Popup Interface** (`popup.html/js`): Update extension popup
3. **Full Page View** (`fullpage.html/js`): Enhance management features

### Customization
- Modify colors in CSS sections of HTML files
- Add new features in the respective JavaScript files
- Update manifest.json for new permissions if needed

## 🔍 Troubleshooting

### Common Issues

**Extension not loading:**
- Ensure all files are in the same directory
- Check that `manifest.json` is valid JSON
- Verify host permissions match your ChatGPT URL

**Pins not saving:**
- Check browser console for errors
- Ensure storage permissions are granted
- Try refreshing the ChatGPT page

**Categories not working:**
- Verify category names don't have special characters
- Check browser storage quotas
- Clear extension data and reinstall if needed

**UI not displaying correctly:**
- Hard refresh the page (Ctrl+F5)
- Check for JavaScript errors in console
- Ensure no conflicting CSS from ChatGPT

### Debug Mode
Open browser console and look for:
- `PinGPTChat:` prefixed messages for normal operation
- Error messages for troubleshooting
- Debug information when issues occur

## 📋 Requirements

- **Chrome Browser**: Version 88 or higher
- **ChatGPT Account**: Works with both chat.openai.com and chatgpt.com
- **Storage Permissions**: Automatically requested on first use

## 🔒 Privacy & Security

- **Local Storage Only**: All data stored locally in Chrome
- **No External Servers**: Extension works entirely offline
- **No Data Collection**: Your conversations remain private
- **Sync Compatible**: Data syncs across Chrome instances when enabled

## 🤝 Contributing

To contribute or report issues:
1. Check existing functionality in the current version
2. Test thoroughly across different ChatGPT interface versions
3. Ensure compatibility with both ChatGPT domains
4. Follow the existing code style and structure

## 📄 License

This project is open source and available for personal and educational use.

---

**Made with ❤️ for ChatGPT users who need better conversation management!**